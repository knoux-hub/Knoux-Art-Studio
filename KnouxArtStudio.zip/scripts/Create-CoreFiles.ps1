# Create-CoreFiles.ps1
param([string]$DriveLetter="F", [string]$ProjectName="KnouxArtStudio")
Write-Host "Creating core files..." -ForegroundColor Cyan