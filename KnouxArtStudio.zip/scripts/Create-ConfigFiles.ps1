# Create-ConfigFiles.ps1
param([string]$DriveLetter="F", [string]$ProjectName="KnouxArtStudio")
Write-Host "Creating config files..." -ForegroundColor Cyan